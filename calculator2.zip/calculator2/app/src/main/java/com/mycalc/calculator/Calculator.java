package com.mycalc.calculator;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static java.lang.Math.*;

public class Calculator extends AppCompatActivity implements View.OnClickListener {
    private Button add,sub,mult,div,sq_rt,power,clear;
    private TextView result;
    private EditText num1, num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        init();
    }

    private void init() {
        add = (Button)findViewById(R.id.add);
        sub = (Button)findViewById(R.id.sub);
        mult = (Button)findViewById(R.id.mult);
        div = (Button)findViewById(R.id.div);
        sq_rt = (Button)findViewById(R.id.sq_rt);
        power = (Button)findViewById(R.id.power);
        clear = (Button)findViewById(R.id.clear);
        num1 = (EditText)findViewById(R.id.num1);
        num2 = (EditText)findViewById(R.id.num2);
        result = (TextView)findViewById(R.id.result);

        add.setOnClickListener(this);
        sub.setOnClickListener(this);
        mult.setOnClickListener(this);
        div.setOnClickListener(this);
        sq_rt.setOnClickListener(this);
        power.setOnClickListener(this);
        clear.setOnClickListener(this);

    }
    @Override
    public void onClick(View view){
        String num_1 = num1.getText().toString();
        String num_2 = num2.getText().toString();
        switch (view.getId()){
            case R.id.add:
                double addition = Double.parseDouble(num_1)+Double.parseDouble(num_2);
                result.setText(String.valueOf(addition));
                break;
            case R.id.sub:
                double subtraction = Double.parseDouble(num_1)-Double.parseDouble(num_2);
                result.setText(String.valueOf(subtraction));
                break;
            case R.id.div:
                try{
                    double division = Double.parseDouble(num_1)/Double.parseDouble(num_2);
                    result.setText(String.valueOf(division));
                }catch(Exception e){
                    result.setText("Error: Divison by zero!!");}
                    break;
            case R.id.mult:
                double multiplication = Double.parseDouble(num_1)*Double.parseDouble(num_2);
                result.setText(String.valueOf(multiplication));
                break;
            case R.id.sq_rt:
                if (Double.parseDouble(num_1) > 0 || Double.parseDouble(num_1) > 0) {
                double square_root = sqrt(Double.parseDouble(num_1));
                result.setText(String.valueOf(square_root));
            }else {
                    result.setText("Error: Please enter a Positive Number!!");
                }
                break;
            case R.id.power:
                double po_wer = pow(Double.parseDouble(num_1), Double.parseDouble(num_2));
                result.setText(String.valueOf(po_wer));
                break;
            case R.id.clear:
                num1.setText("");
                num2.setText("");
                result.setText("");
                break;



        }
    }

}
